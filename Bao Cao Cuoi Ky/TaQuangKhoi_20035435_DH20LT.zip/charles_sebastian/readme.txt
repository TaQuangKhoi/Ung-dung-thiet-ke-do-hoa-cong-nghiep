NOTE: This demo font is FREE for PERSONAL USE ONLY! 

For Commercial Use visit my webstore kotakkuning.com

By installing or using this font, you are agree to the Product Usage Agreement:

1. This font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
2. You are requires a license for PROMOTIONAL or COMMERCIAL use. 
3. CONTACT ME before any Promotional or Commercial Use!

EMAIL SUPPORT: kotakkuningstudio@gmail.com

And follow my instagram for update: @kotakkuningstudio

Regards,
Kotak Kuning Studio